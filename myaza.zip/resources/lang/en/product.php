<?php

return [
    'map_attribute_not_exists' => 'Map attribute not exists for selected category and subcategory',
    'updated'  => 'Your product has been updated!',
    'created'  => 'Your product has been created!',
];