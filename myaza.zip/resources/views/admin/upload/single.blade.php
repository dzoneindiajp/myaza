
`
<img src="${imagesrc}" style="width : 120px;" class="my-2"/>
<input type="hidden" name="${identity}" value="${name}"/>
`
